export interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  description: string;
  specs: string[];
  image: string;
  features: string[];
}

export interface CartItem extends Product {
  quantity: number;
}

export enum PageState {
  HOME = 'HOME',
  PRODUCTS = 'PRODUCTS',
  PRODUCT_DETAIL = 'PRODUCT_DETAIL',
  ABOUT = 'ABOUT',
  CONTACT = 'CONTACT',
  BLOG = 'BLOG',
  LEGAL = 'LEGAL',
  FAQ = 'FAQ'
}