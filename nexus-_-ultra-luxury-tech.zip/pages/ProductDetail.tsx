import React from 'react';
import { Product, PageState } from '../types';
import { FadeIn, Reveal } from '../components/Animations';
import { ArrowLeft, Check, Star, Shield, Truck } from 'lucide-react';

interface Props {
  product: Product;
  addToCart: (product: Product) => void;
  goBack: () => void;
}

const ProductDetail: React.FC<Props> = ({ product, addToCart, goBack }) => {
  return (
    <div className="min-h-screen pt-24 pb-20">
      {/* Breadcrumb */}
      <div className="max-w-7xl mx-auto px-6 mb-8">
        <button 
          onClick={goBack} 
          className="flex items-center text-gray-500 hover:text-white transition-colors text-sm uppercase tracking-wider"
        >
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Collection
        </button>
      </div>

      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-16">
        {/* Images */}
        <div className="space-y-4">
          <FadeIn>
            <div className="aspect-square bg-[#111] border border-white/5 rounded-sm overflow-hidden relative">
               <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
            </div>
          </FadeIn>
          <div className="grid grid-cols-2 gap-4">
            <div className="aspect-video bg-[#111] border border-white/5 rounded-sm" />
            <div className="aspect-video bg-[#111] border border-white/5 rounded-sm" />
          </div>
        </div>

        {/* Details */}
        <div className="relative">
           <FadeIn delay={0.2}>
             <div className="sticky top-32">
               <span className="text-blue-400 uppercase tracking-widest text-xs font-bold mb-4 block">
                 {product.category} Series
               </span>
               <h1 className="text-5xl font-bold mb-4 tracking-tight leading-tight">{product.name}</h1>
               <div className="flex items-center space-x-4 mb-8 border-b border-white/10 pb-8">
                 <span className="text-3xl font-light">${product.price.toLocaleString()}</span>
                 <div className="flex items-center text-yellow-500 text-sm">
                   <Star className="w-4 h-4 fill-current" />
                   <Star className="w-4 h-4 fill-current" />
                   <Star className="w-4 h-4 fill-current" />
                   <Star className="w-4 h-4 fill-current" />
                   <Star className="w-4 h-4 fill-current" />
                   <span className="text-gray-500 ml-2">(24 Reviews)</span>
                 </div>
               </div>

               <p className="text-gray-300 text-lg leading-relaxed mb-8">
                 {product.description}
               </p>

               {/* Specs Grid */}
               <div className="grid grid-cols-2 gap-4 mb-10">
                 {product.specs.map((spec, i) => (
                   <div key={i} className="bg-white/5 p-4 rounded-sm border border-white/5">
                     <span className="text-gray-500 text-xs uppercase block mb-1">Feature</span>
                     <span className="text-white font-medium">{spec}</span>
                   </div>
                 ))}
               </div>

               {/* Actions */}
               <div className="flex space-x-4 mb-12">
                 <button 
                   onClick={() => addToCart(product)}
                   className="flex-1 bg-white text-black py-4 font-medium uppercase tracking-wider hover:bg-gray-200 transition-colors rounded-sm"
                 >
                   Add to Cart
                 </button>
                 <button className="flex-1 border border-white/20 text-white py-4 font-medium uppercase tracking-wider hover:bg-white/10 transition-colors rounded-sm">
                   Financing
                 </button>
               </div>

               {/* Trust Badges */}
               <div className="grid grid-cols-3 gap-4 text-center text-xs text-gray-500">
                  <div className="flex flex-col items-center">
                    <Truck className="w-6 h-6 mb-2 text-gray-300" />
                    <span>Free Global Shipping</span>
                  </div>
                  <div className="flex flex-col items-center">
                    <Shield className="w-6 h-6 mb-2 text-gray-300" />
                    <span>2 Year Warranty</span>
                  </div>
                  <div className="flex flex-col items-center">
                    <Check className="w-6 h-6 mb-2 text-gray-300" />
                    <span>30-Day Returns</span>
                  </div>
               </div>
             </div>
           </FadeIn>
        </div>
      </div>

      {/* Tech Specs Table */}
      <section className="mt-32 max-w-4xl mx-auto px-6">
        <Reveal>
          <h2 className="text-2xl font-bold mb-8">Technical Specifications</h2>
          <div className="border-t border-white/10">
            {[
              { label: 'Dimensions', value: '142mm x 72mm x 8mm' },
              { label: 'Weight', value: '182g' },
              { label: 'Materials', value: 'Aerospace Grade Titanium, Ceramic Shield' },
              { label: 'Connectivity', value: '5G, Wi-Fi 6E, Bluetooth 5.3' },
              { label: 'In the Box', value: 'Device, USB-C Cable, Documentation' },
            ].map((row, i) => (
              <div key={i} className="flex justify-between py-6 border-b border-white/10">
                <span className="text-gray-500">{row.label}</span>
                <span className="text-white">{row.value}</span>
              </div>
            ))}
          </div>
        </Reveal>
      </section>
    </div>
  );
};

export default ProductDetail;