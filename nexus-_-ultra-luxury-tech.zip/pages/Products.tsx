import React, { useState } from 'react';
import { PRODUCTS, CATEGORIES } from '../constants';
import { Product, PageState } from '../types';
import { Reveal, TiltCard, FadeIn } from '../components/Animations';
import { Filter } from 'lucide-react';

interface Props {
  onProductClick: (product: Product) => void;
  setPage: (page: PageState) => void;
}

const Products: React.FC<Props> = ({ onProductClick, setPage }) => {
  const [activeCategory, setActiveCategory] = useState('All');

  const filteredProducts = activeCategory === 'All' 
    ? PRODUCTS 
    : PRODUCTS.filter(p => p.category === activeCategory);

  return (
    <div className="min-h-screen pt-32 pb-20 px-6 max-w-7xl mx-auto">
      <FadeIn>
        <div className="flex flex-col md:flex-row justify-between items-baseline mb-16">
          <h1 className="text-4xl md:text-6xl font-bold tracking-tighter mb-6 md:mb-0">
            Collection <span className="text-gray-600 text-2xl align-top font-normal">({filteredProducts.length})</span>
          </h1>
          
          <div className="flex items-center space-x-6 overflow-x-auto pb-4 md:pb-0 scrollbar-hide">
             <Filter className="w-4 h-4 text-gray-500 hidden md:block" />
             {CATEGORIES.map(cat => (
               <button
                 key={cat}
                 onClick={() => setActiveCategory(cat)}
                 className={`text-sm uppercase tracking-wider whitespace-nowrap transition-colors ${
                   activeCategory === cat ? 'text-white border-b border-white' : 'text-gray-500 hover:text-white'
                 }`}
               >
                 {cat}
               </button>
             ))}
          </div>
        </div>
      </FadeIn>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-12">
        {filteredProducts.map((product) => (
          <Reveal key={product.id}>
             <TiltCard className="group cursor-pointer h-full">
                <div 
                  onClick={() => onProductClick(product)}
                  className="h-full flex flex-col"
                >
                  <div className="bg-[#111] relative overflow-hidden aspect-[4/5] mb-6 rounded-sm border border-white/5 hover:border-white/20 transition-all duration-500">
                    <img 
                      src={product.image} 
                      alt={product.name} 
                      className="w-full h-full object-cover grayscale opacity-80 group-hover:opacity-100 group-hover:grayscale-0 transition-all duration-700 transform group-hover:scale-110"
                    />
                    <div className="absolute top-4 right-4 bg-white/10 backdrop-blur-md px-3 py-1 rounded-full text-[10px] uppercase tracking-widest text-white border border-white/10">
                      {product.category}
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="text-xl font-medium mb-2 group-hover:text-gray-300 transition-colors">{product.name}</h3>
                      <div className="flex space-x-2 text-xs text-gray-500 mb-4">
                        {product.features.slice(0, 2).map(f => (
                          <span key={f} className="border border-white/10 px-2 py-1 rounded-sm">{f}</span>
                        ))}
                      </div>
                    </div>
                    <span className="text-lg font-light">${product.price.toLocaleString()}</span>
                  </div>
                </div>
             </TiltCard>
          </Reveal>
        ))}
      </div>
    </div>
  );
};

export default Products;