import React from 'react';
import { ArrowRight, Play } from 'lucide-react';
import { PRODUCTS } from '../constants';
import { Reveal, TiltCard, FadeIn } from '../components/Animations';
import { PageState, Product } from '../types';
import { motion, useScroll, useTransform } from 'framer-motion';

interface Props {
  setPage: (page: PageState) => void;
  onProductClick: (product: Product) => void;
}

const Home: React.FC<Props> = ({ setPage, onProductClick }) => {
  const { scrollY } = useScroll();
  const y1 = useTransform(scrollY, [0, 500], [0, 200]);
  const opacity = useTransform(scrollY, [0, 400], [1, 0]);

  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="relative h-screen w-full overflow-hidden flex items-center justify-center">
        {/* Parallax Background */}
        <motion.div style={{ y: y1 }} className="absolute inset-0 z-0">
          <img 
            src="https://picsum.photos/1920/1080?grayscale&blur=2" 
            alt="Hero Background" 
            className="w-full h-full object-cover opacity-40 scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-black/40 to-[#050505]" />
        </motion.div>

        {/* Hero Content */}
        <motion.div style={{ opacity }} className="relative z-10 text-center px-4 max-w-4xl">
          <FadeIn delay={0.2}>
            <span className="inline-block py-1 px-3 border border-white/20 rounded-full text-xs uppercase tracking-[0.2em] text-gray-300 mb-6 bg-black/30 backdrop-blur-sm">
              The Future is Now
            </span>
          </FadeIn>
          <FadeIn delay={0.4}>
            <h1 className="text-5xl md:text-8xl font-bold tracking-tighter mb-8 bg-clip-text text-transparent bg-gradient-to-b from-white to-gray-500">
              BEYOND REALITY
            </h1>
          </FadeIn>
          <FadeIn delay={0.6}>
            <p className="text-lg md:text-xl text-gray-400 mb-10 max-w-2xl mx-auto leading-relaxed">
              Experience the convergence of luxury design and bleeding-edge technology.
            </p>
          </FadeIn>
          <FadeIn delay={0.8}>
            <div className="flex flex-col md:flex-row items-center justify-center space-y-4 md:space-y-0 md:space-x-6">
              <button 
                onClick={() => setPage(PageState.PRODUCTS)}
                className="px-8 py-4 bg-white text-black font-medium tracking-wide hover:bg-gray-200 transition-all duration-300 rounded-sm w-full md:w-auto"
              >
                Shop Collection
              </button>
              <button className="px-8 py-4 border border-white/20 text-white font-medium tracking-wide hover:bg-white/10 transition-all duration-300 rounded-sm backdrop-blur-sm flex items-center justify-center w-full md:w-auto">
                <Play className="w-4 h-4 mr-2" fill="currentColor" /> Watch Film
              </button>
            </div>
          </FadeIn>
        </motion.div>
      </section>

      {/* Featured Grid */}
      <section className="py-32 px-6 max-w-7xl mx-auto">
        <Reveal>
           <div className="flex justify-between items-end mb-16 border-b border-white/10 pb-8">
             <div>
                <h2 className="text-3xl md:text-4xl font-semibold tracking-tight mb-2">Latest Drops</h2>
                <p className="text-gray-500">Curated for the visionary.</p>
             </div>
             <button onClick={() => setPage(PageState.PRODUCTS)} className="hidden md:flex items-center text-sm font-medium hover:text-gray-400 transition-colors">
                View All <ArrowRight className="ml-2 w-4 h-4" />
             </button>
           </div>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {PRODUCTS.slice(0, 3).map((product, index) => (
            <Reveal key={product.id} delay={index * 0.2}>
              <TiltCard className="group cursor-pointer">
                <div 
                  onClick={() => onProductClick(product)}
                  className="bg-[#0f0f0f] border border-white/5 p-8 relative overflow-hidden transition-colors hover:border-white/20"
                >
                  <div className="aspect-square mb-8 relative">
                    <img 
                      src={product.image} 
                      alt={product.name} 
                      className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 ease-out transform group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0f0f0f] to-transparent opacity-20" />
                  </div>
                  
                  <div className="relative z-10">
                    <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">{product.category}</p>
                    <h3 className="text-xl font-medium mb-1 group-hover:text-white transition-colors">{product.name}</h3>
                    <p className="text-gray-400">${product.price.toLocaleString()}</p>
                  </div>
                  
                  {/* Hover Glow */}
                  <div className="absolute -inset-full top-0 block h-full w-1/2 -skew-x-12 bg-gradient-to-r from-transparent to-white opacity-0 group-hover:animate-shine" />
                </div>
              </TiltCard>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Big Feature Section */}
      <section className="py-20 bg-neutral-900 border-y border-white/5 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
           <Reveal>
             <div className="relative z-10">
                <span className="text-blue-400 uppercase tracking-widest text-xs font-bold mb-4 block">Engineered for Excellence</span>
                <h2 className="text-4xl md:text-6xl font-bold mb-8 leading-tight">NEXUS Vision Pro</h2>
                <p className="text-gray-400 text-lg mb-8 leading-relaxed">
                  Redefining spatial computing with industry-leading 8K micro-OLED displays. 
                  Experience immersion like never before with 12ms photon-to-motion latency.
                </p>
                <ul className="space-y-4 mb-10">
                  {['Micro-OLED 4K per eye', 'M3 + R1 Chipset', 'Eyesight Technology'].map(feat => (
                    <li key={feat} className="flex items-center text-gray-300">
                      <div className="w-1.5 h-1.5 bg-white rounded-full mr-4" />
                      {feat}
                    </li>
                  ))}
                </ul>
                <button 
                  onClick={() => onProductClick(PRODUCTS[0])}
                  className="bg-white text-black px-8 py-4 font-medium rounded-sm hover:bg-gray-200 transition-colors"
                >
                  Pre-order Now
                </button>
             </div>
           </Reveal>
           <Reveal delay={0.3}>
             <div className="relative">
                <div className="absolute inset-0 bg-blue-500/10 blur-[100px] rounded-full pointer-events-none" />
                <img 
                  src="https://picsum.photos/800/800?grayscale" 
                  alt="Vision Pro" 
                  className="relative z-10 w-full rounded-sm shadow-2xl border border-white/10"
                />
             </div>
           </Reveal>
        </div>
      </section>

      {/* Categories Marquee */}
      <section className="py-24 overflow-hidden">
        <div className="flex whitespace-nowrap space-x-12 animate-marquee">
          {[...Array(2)].map((_, i) => (
             <React.Fragment key={i}>
                <span className="text-8xl font-black text-transparent stroke-text opacity-20">AUDIO</span>
                <span className="text-8xl font-black text-white opacity-80">VISION</span>
                <span className="text-8xl font-black text-transparent stroke-text opacity-20">WEARABLES</span>
                <span className="text-8xl font-black text-white opacity-80">HOME</span>
                <span className="text-8xl font-black text-transparent stroke-text opacity-20">COMPUTING</span>
             </React.Fragment>
          ))}
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-32 max-w-4xl mx-auto px-6 text-center">
        <Reveal>
          <div className="mb-12">
            <h2 className="text-2xl font-light mb-4">"The most refined technology retail experience of the decade."</h2>
            <div className="flex justify-center space-x-1">
              {[...Array(5)].map((_, i) => <span key={i} className="text-yellow-500 text-xl">★</span>)}
            </div>
          </div>
          <p className="text-gray-500 uppercase tracking-widest text-sm">— TechDaily Magazine</p>
        </Reveal>
      </section>
    </div>
  );
};

export default Home;