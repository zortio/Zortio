import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Products from './pages/Products';
import ProductDetail from './pages/ProductDetail';
import AIConcierge from './components/AIConcierge';
import { GenericPage } from './pages/GenericPage';
import { PageState, Product } from './types';
import { AnimatePresence, motion } from 'framer-motion';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<PageState>(PageState.HOME);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [cartCount, setCartCount] = useState(0);

  // Scroll to top on page change
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [currentPage]);

  const handleProductClick = (product: Product) => {
    setSelectedProduct(product);
    setCurrentPage(PageState.PRODUCT_DETAIL);
  };

  const handleAddToCart = (product: Product) => {
    setCartCount(prev => prev + 1);
    // Simple toast could be added here
  };

  const renderPage = () => {
    switch (currentPage) {
      case PageState.HOME:
        return <Home setPage={setCurrentPage} onProductClick={handleProductClick} />;
      case PageState.PRODUCTS:
        return <Products setPage={setCurrentPage} onProductClick={handleProductClick} />;
      case PageState.PRODUCT_DETAIL:
        return selectedProduct ? (
          <ProductDetail 
            product={selectedProduct} 
            addToCart={handleAddToCart}
            goBack={() => setCurrentPage(PageState.PRODUCTS)} 
          />
        ) : <Products setPage={setCurrentPage} onProductClick={handleProductClick} />;
      case PageState.ABOUT:
        return <GenericPage title="About NEXUS" subtitle="Defining the cutting edge of luxury technology." />;
      case PageState.CONTACT:
        return (
          <GenericPage title="Contact Us" subtitle="We're here to help. Reach out to our concierge team.">
             <form className="space-y-6 mt-8">
               <div className="grid grid-cols-2 gap-6">
                 <input type="text" placeholder="First Name" className="bg-transparent border-b border-gray-700 py-3 text-white outline-none focus:border-white transition-colors" />
                 <input type="text" placeholder="Last Name" className="bg-transparent border-b border-gray-700 py-3 text-white outline-none focus:border-white transition-colors" />
               </div>
               <input type="email" placeholder="Email Address" className="w-full bg-transparent border-b border-gray-700 py-3 text-white outline-none focus:border-white transition-colors" />
               <textarea placeholder="Message" rows={4} className="w-full bg-transparent border-b border-gray-700 py-3 text-white outline-none focus:border-white transition-colors"></textarea>
               <button className="bg-white text-black px-8 py-3 uppercase tracking-wider font-medium text-sm hover:bg-gray-200">Send Message</button>
             </form>
          </GenericPage>
        );
      case PageState.BLOG:
        return <GenericPage title="The Journal" subtitle="Insights, updates, and stories from the lab." />;
      case PageState.LEGAL:
        return <GenericPage title="Legal" subtitle="Terms, conditions, and privacy protocols." />;
      case PageState.FAQ:
        return (
           <GenericPage title="FAQ" subtitle="Common questions about our products and services.">
              <div className="space-y-8">
                {[
                  { q: "What is the warranty period?", a: "All NEXUS products come with a comprehensive 2-year international warranty covering all hardware defects." },
                  { q: "Do you ship globally?", a: "Yes, we provide complimentary expedited shipping to over 100 countries worldwide via our logistics partners." },
                  { q: "What is the return policy?", a: "We offer a 30-day no-questions-asked return policy. If you are not completely satisfied, simply return the device in its original packaging." }
                ].map((item, i) => (
                  <div key={i} className="border-b border-white/10 pb-6">
                    <h3 className="text-lg font-medium mb-2 text-white">{item.q}</h3>
                    <p className="text-gray-400">{item.a}</p>
                  </div>
                ))}
              </div>
           </GenericPage>
        );
      default:
        return <Home setPage={setCurrentPage} onProductClick={handleProductClick} />;
    }
  };

  return (
    <div className="bg-[#050505] text-gray-100 min-h-screen font-sans selection:bg-white/20 selection:text-white">
      <Navbar setPage={setCurrentPage} cartCount={cartCount} />
      
      <main className="relative z-10">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5 }}
          >
            {renderPage()}
          </motion.div>
        </AnimatePresence>
      </main>

      <Footer setPage={setCurrentPage} />
      <AIConcierge />
    </div>
  );
};

export default App;