import { GoogleGenAI } from "@google/genai";
import { PRODUCTS } from '../constants';

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.error("API_KEY is missing in environment variables.");
    return null;
  }
  return new GoogleGenAI({ apiKey });
};

export const generateConciergeResponse = async (userQuery: string, chatHistory: string): Promise<string> => {
  const client = getClient();
  if (!client) return "I apologize, but my connection to the mainframe is currently unavailable.";

  const productContext = PRODUCTS.map(p => 
    `${p.name} ($${p.price}) - ${p.description}. Key specs: ${p.specs.join(', ')}.`
  ).join('\n');

  const systemInstruction = `
    You are NEXUS, an ultra-luxury AI concierge for a high-end electronics store. 
    Your tone is sophisticated, minimalist, and extremely helpful, similar to a high-end boutique assistant.
    Keep answers concise and elegant. Do not use emojis. Use professional formatting.
    
    Here is our exclusive product catalog:
    ${productContext}
    
    If the user asks about products we don't have, politely steer them towards our available collection.
    If they ask for a recommendation, analyze their needs and suggest specific items from the catalog.
  `;

  try {
    const response = await client.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `History: ${chatHistory}\nUser: ${userQuery}`,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.7,
        maxOutputTokens: 300,
      }
    });

    return response.text || "I am unable to process that request at this moment.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "I am currently experiencing a temporary disturbance in my neural network.";
  }
};