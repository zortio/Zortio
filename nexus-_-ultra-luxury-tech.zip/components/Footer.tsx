import React from 'react';
import { PageState } from '../types';

interface Props {
  setPage: (page: PageState) => void;
}

const Footer: React.FC<Props> = ({ setPage }) => {
  return (
    <footer className="bg-black border-t border-white/10 pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-20">
          <div>
            <h2 className="text-xl font-bold tracking-[0.2em] mb-6">NEXUS</h2>
            <p className="text-sm text-gray-500 leading-relaxed">
              Crafting the future of personal technology. Designed in California, engineered for the cosmos.
            </p>
          </div>
          
          <div>
            <h3 className="text-xs uppercase tracking-widest text-gray-400 mb-6">Explore</h3>
            <ul className="space-y-4 text-sm text-gray-300">
              <li onClick={() => setPage(PageState.PRODUCTS)} className="cursor-pointer hover:text-white transition-colors">Products</li>
              <li onClick={() => setPage(PageState.ABOUT)} className="cursor-pointer hover:text-white transition-colors">Our Story</li>
              <li className="cursor-pointer hover:text-white transition-colors">Careers</li>
              <li className="cursor-pointer hover:text-white transition-colors">Press</li>
            </ul>
          </div>

          <div>
            <h3 className="text-xs uppercase tracking-widest text-gray-400 mb-6">Support</h3>
            <ul className="space-y-4 text-sm text-gray-300">
              <li onClick={() => setPage(PageState.FAQ)} className="cursor-pointer hover:text-white transition-colors">FAQ</li>
              <li className="cursor-pointer hover:text-white transition-colors">Shipping & Returns</li>
              <li className="cursor-pointer hover:text-white transition-colors">Warranty</li>
              <li onClick={() => setPage(PageState.CONTACT)} className="cursor-pointer hover:text-white transition-colors">Contact Us</li>
            </ul>
          </div>

          <div>
            <h3 className="text-xs uppercase tracking-widest text-gray-400 mb-6">Newsletter</h3>
            <div className="flex border-b border-gray-700 pb-2">
              <input 
                type="email" 
                placeholder="EMAIL ADDRESS" 
                className="bg-transparent w-full outline-none text-sm text-white placeholder-gray-600"
              />
              <button className="text-xs uppercase tracking-widest text-gray-400 hover:text-white transition-colors">
                Join
              </button>
            </div>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center text-xs text-gray-600 pt-8 border-t border-white/5">
          <p>&copy; 2024 NEXUS Systems Inc. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
             <span onClick={() => setPage(PageState.LEGAL)} className="cursor-pointer hover:text-gray-400">Privacy Policy</span>
             <span className="cursor-pointer hover:text-gray-400">Terms of Service</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;