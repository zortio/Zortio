import React, { useState, useEffect } from 'react';
import { Menu, X, ShoppingBag, Search, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { PageState } from '../types';

interface NavbarProps {
  setPage: (page: PageState) => void;
  cartCount: number;
}

const Navbar: React.FC<NavbarProps> = ({ setPage, cartCount }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isMegaMenuOpen, setIsMegaMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Products', page: PageState.PRODUCTS, hasMega: true },
    { label: 'About', page: PageState.ABOUT },
    { label: 'Blog', page: PageState.BLOG },
    { label: 'Contact', page: PageState.CONTACT },
  ];

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ease-in-out ${
          isScrolled ? 'glass py-4' : 'bg-transparent py-6'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
          {/* Logo */}
          <div 
            onClick={() => setPage(PageState.HOME)}
            className="cursor-pointer z-50 group"
          >
            <h1 className="text-2xl font-bold tracking-[0.2em] group-hover:opacity-70 transition-opacity">
              NEXUS
            </h1>
          </div>

          {/* Desktop Links */}
          <div className="hidden md:flex items-center space-x-12">
            {navLinks.map((link) => (
              <div 
                key={link.label} 
                className="relative group h-full"
                onMouseEnter={() => link.hasMega && setIsMegaMenuOpen(true)}
                onMouseLeave={() => link.hasMega && setIsMegaMenuOpen(false)}
              >
                <button
                  onClick={() => {
                    setPage(link.page);
                    setIsMegaMenuOpen(false);
                  }}
                  className="text-sm font-medium tracking-wide text-gray-300 hover:text-white transition-colors py-2 uppercase"
                >
                  {link.label}
                </button>
                {/* Underline Effect */}
                <span className="absolute bottom-0 left-0 w-0 h-[1px] bg-white transition-all duration-300 group-hover:w-full" />
              </div>
            ))}
          </div>

          {/* Icons */}
          <div className="hidden md:flex items-center space-x-6">
            <Search className="w-5 h-5 text-gray-300 hover:text-white cursor-pointer transition-colors" />
            <div className="relative cursor-pointer group">
              <ShoppingBag className="w-5 h-5 text-gray-300 group-hover:text-white transition-colors" />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 w-4 h-4 bg-white text-black text-[10px] font-bold flex items-center justify-center rounded-full">
                  {cartCount}
                </span>
              )}
            </div>
          </div>

          {/* Mobile Menu Toggle */}
          <button 
            className="md:hidden z-50 text-white"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mega Menu Overlay */}
        <AnimatePresence>
          {isMegaMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.2 }}
              onMouseEnter={() => setIsMegaMenuOpen(true)}
              onMouseLeave={() => setIsMegaMenuOpen(false)}
              className="absolute top-full left-0 w-full glass border-t border-white/5 pb-12 pt-8"
            >
              <div className="max-w-7xl mx-auto px-6 grid grid-cols-4 gap-8">
                <div>
                  <h3 className="text-xs uppercase tracking-widest text-gray-500 mb-4">Categories</h3>
                  <ul className="space-y-3">
                    {['Audio', 'Wearables', 'Displays', 'Mobile', 'Accessories'].map(item => (
                      <li key={item} className="text-sm text-gray-300 hover:text-white cursor-pointer hover:translate-x-1 transition-transform">
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h3 className="text-xs uppercase tracking-widest text-gray-500 mb-4">Featured</h3>
                  <ul className="space-y-3">
                    {['New Arrivals', 'Best Sellers', 'Limited Edition', 'Gift Guide'].map(item => (
                      <li key={item} className="text-sm text-gray-300 hover:text-white cursor-pointer hover:translate-x-1 transition-transform">
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="col-span-2 border-l border-white/10 pl-8">
                  <div className="group cursor-pointer relative overflow-hidden rounded-sm h-48 w-full bg-neutral-900">
                     <img src="https://picsum.photos/600/300?grayscale" alt="Feature" className="w-full h-full object-cover opacity-60 group-hover:opacity-80 transition-opacity duration-500 group-hover:scale-105 transform" />
                     <div className="absolute bottom-4 left-4">
                        <p className="text-xs uppercase tracking-wider text-white">Just Dropped</p>
                        <h4 className="text-xl font-bold text-white mt-1">The Black Edition</h4>
                     </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Mobile Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 bg-black flex flex-col justify-center items-center space-y-8"
          >
            {navLinks.map((link) => (
              <button
                key={link.label}
                onClick={() => {
                  setPage(link.page);
                  setIsMobileMenuOpen(false);
                }}
                className="text-2xl font-light uppercase tracking-widest hover:text-gray-400 transition-colors"
              >
                {link.label}
              </button>
            ))}
            <button className="text-sm text-gray-500 mt-8">My Account</button>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default Navbar;