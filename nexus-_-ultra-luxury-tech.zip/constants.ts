import { Product } from './types';

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'NEXUS Vision Pro',
    price: 3499,
    category: 'Wearables',
    description: 'Spatial computing headset with 8K micro-OLED displays and eye tracking.',
    specs: ['M3 Chip', '256GB Storage', '2hrs Battery', '3D Camera'],
    image: 'https://picsum.photos/800/800?grayscale&random=1',
    features: ['Immersive Environment', 'Eye Control', 'Spatial Audio']
  },
  {
    id: '2',
    name: 'Aether Speaker X1',
    price: 899,
    category: 'Audio',
    description: 'High-fidelity wireless speaker with active room calibration.',
    specs: ['360 Sound', 'Wifi 6E', 'AirPlay 2', 'Titanium Driver'],
    image: 'https://picsum.photos/800/800?grayscale&random=2',
    features: ['Room Calibration', 'Multi-room Sync', 'Voice Control']
  },
  {
    id: '3',
    name: 'Chronos Watch Ultra',
    price: 1299,
    category: 'Wearables',
    description: 'Aerospace-grade titanium smartwatch with sapphire crystal.',
    specs: ['Titanium Case', '100m Water Resist', 'ECG', 'OLED Retina'],
    image: 'https://picsum.photos/800/800?grayscale&random=3',
    features: ['Health Tracking', 'Satellite SOS', 'Action Button']
  },
  {
    id: '4',
    name: 'Lumix Frame 55',
    price: 2199,
    category: 'Display',
    description: 'Ultra-thin 8K OLED display that doubles as digital art canvas.',
    specs: ['8K Resolution', 'Matte Finish', 'Art Mode', '120Hz'],
    image: 'https://picsum.photos/800/800?grayscale&random=4',
    features: ['Anti-Glare', 'Art Store', 'Slim Mount']
  },
  {
    id: '5',
    name: 'Sonic Pods Max',
    price: 549,
    category: 'Audio',
    description: 'Over-ear noise cancelling headphones with computational audio.',
    specs: ['ANC', '40hrs Battery', 'Transparency Mode', 'MagSafe'],
    image: 'https://picsum.photos/800/800?grayscale&random=5',
    features: ['Adaptive EQ', 'Spatial Audio', 'Seamless Switching']
  },
  {
    id: '6',
    name: 'Obsidian Phone 15',
    price: 1199,
    category: 'Mobile',
    description: 'The pinnacle of mobile computing encased in ceramic shield.',
    specs: ['A17 Pro', '48MP Camera', 'USB-C', '1TB Storage'],
    image: 'https://picsum.photos/800/800?grayscale&random=6',
    features: ['Ray Tracing', 'ProRaw', 'Action Mode']
  }
];

export const CATEGORIES = ['All', 'Audio', 'Wearables', 'Display', 'Mobile'];